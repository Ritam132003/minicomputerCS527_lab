#include <stdio.h>
#include <string.h>

#include "compiler.h"

void compile()
{
    FILE *input;
    FILE *output;

    char line[100];

    input = fopen("program.txt", "r");
    output = fopen("program.byte", "w");

    if(input == NULL || output == NULL)
    {
        printf("Error opening files.\n");
        return;
    }

    while(fgets(line, sizeof(line), input))
    {
        int dest;
        int src1;
        int src2;
        int value;

        /* Skip empty lines */
        if(strlen(line) <= 1)
            continue;

        /* READ */

        if(strncmp(line,"Read",4)==0)
        {
            sscanf(line,"Read x%d %d",&dest,&src1);

            fprintf(output,
                    "5 %d %d 0\n",
                    dest,
                    src1);
        }

        /* WRITE */

        else if(strncmp(line,"Write",5)==0)
        {
            sscanf(line,
                   "Write x%d %d",
                   &dest,
                   &src1);

            fprintf(output,
                    "6 %d %d 0\n",
                    dest,
                    src1);
        }

        /* ADD */

        else if(strchr(line,'+')!=NULL)
        {
            sscanf(line,
                   "x%d = x%d + x%d",
                   &dest,
                   &src1,
                   &src2);

            fprintf(output,
                    "1 %d %d %d\n",
                    dest,
                    src1,
                    src2);
        }

        /* SUBTRACT */

        else if(strchr(line,'-')!=NULL)
        {
            sscanf(line,
                   "x%d = x%d - x%d",
                   &dest,
                   &src1,
                   &src2);

            fprintf(output,
                    "2 %d %d %d\n",
                    dest,
                    src1,
                    src2);
        }

        /* MULTIPLY */

        else if(strchr(line,'*')!=NULL)
        {
            sscanf(line,
                   "x%d = x%d * x%d",
                   &dest,
                   &src1,
                   &src2);

            fprintf(output,
                    "3 %d %d %d\n",
                    dest,
                    src1,
                    src2);
        }

        /* DIVIDE */

        else if(strchr(line,'/')!=NULL)
        {
            sscanf(line,
                   "x%d = x%d / x%d",
                   &dest,
                   &src1,
                   &src2);

            fprintf(output,
                    "4 %d %d %d\n",
                    dest,
                    src1,
                    src2);
        }

        /* DATA MOVEMENT */

        else if(strchr(line,'=')!=NULL)
        {
            sscanf(line,
                   "x%d = %d",
                   &dest,
                   &value);

            fprintf(output,
                    "7 %d %d 0\n",
                    dest,
                    value);
        }
    }

    /* End of Program */

    fprintf(output,"0 0 0 0\n");

    fclose(input);
    fclose(output);
}