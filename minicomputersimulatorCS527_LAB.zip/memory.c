#include <stdio.h>
#include "memory.h"

char Instruction[256];
char Data[256];

void initialize()
{
    FILE *fp;
    int value;
    int i;

    for(i = 0; i < 256; i++)
    {
        Instruction[i] = 0;
        Data[i] = 0;
    }

    fp = fopen("program.byte", "r");

    if(fp != NULL)
    {
        i = 0;

        while(fscanf(fp, "%d", &value) == 1)
        {
            Instruction[i] = (char)value;
            i++;
        }

        fclose(fp);
    }

    fp = fopen("data.byte", "r");

    if(fp != NULL)
    {
        i = 0;

        while(fscanf(fp, "%d", &value) == 1)
        {
            Data[i] = (char)value;
            i++;
        }

        fclose(fp);
    }
}

void finalize()
{
    FILE *fp;
    int i;

    fp = fopen("data.byte", "w");

    if(fp != NULL)
    {
        for(i = 0; i < 256; i++)
        {
            fprintf(fp, "%d\n", Data[i]);
        }

        fclose(fp);
    }
}