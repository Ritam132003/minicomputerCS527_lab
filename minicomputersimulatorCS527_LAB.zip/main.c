#include <stdio.h>

#include "compiler.h"
#include "memory.h"
#include "processor.h"

int main()
{
    compile();

    initialize();

    reset();

    while(!end_of_simulation)
    {
        fetch();

        decode();

        execute();
    }

    finalize();

    printf("Program executed successfully.\n");

    return 0;
}